from django.conf import settings

from product.models import Product

class Wishlist(object):
    def __init__(self,request):
        self.session = request.session
        wishlist = self.session.get(settings.WISHLIST_SESSION_KEY)
        if not wishlist:
            wishlist = self.session[settings.WISHLIST_SESSION_KEY] = {}
        self.wishlist = wishlist
 

    def add(self,product):
        product_id = str(product.id)
        self.wishlist[product_id] = product_id

        # del self.cart[product_id]
        self.save()

    def delete(self,product):
        product_id = str(product.id)
        del self.wishlist[product_id]
        self.save()
        
    def save(self):
        self.session.modified = True


    def list(self):
        wishlist = []
        for product_id in self.wishlist.keys():
            obj = Product.objects.get(id=product_id)
            tmp_list = obj
            wishlist.append(tmp_list)
        return wishlist



    def clearcart(self):
        del self.session[settings.CART_SESSION_KEY]
        self.save()