from django.shortcuts import render, redirect, 	get_object_or_404,HttpResponseRedirect
from .models import Wishlist , WishlistItem
from product.models import Product
from django.contrib import messages
from django.views.generic import ListView
from django.urls import reverse

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from wishlist.wishlist import Wishlist as SessionWishlist
from settings.ajax_request import is_ajax
from django.http import JsonResponse

 
def wishlist_add(request, id):
    if is_ajax(request):
        if request.user.is_authenticated:
            url = request.META.get('HTTP_REFERER')
            obj, created = Wishlist.objects.update_or_create(user=request.user)
            product = get_object_or_404(Product, id=id)
            try:
                wishlist_list = WishlistItem.objects.get(wishlist=obj, product=product)
                if  wishlist_list.product.id == product.id:
                    wishlistItems = WishlistItem.objects.filter(wishlist=obj, product=product)
                    wishlistItems.delete()
                return JsonResponse({'status':'true','added':'false','message':'Added to wishlist'})
            except:
                item, itemCreated = WishlistItem.objects.update_or_create(wishlist=obj, product=product)
                obj.wishlist_items.add(item)
                item.save()
                obj.save()
                return JsonResponse({'status':'true', 'added':'true','message':'Added to wishlist'})

        else:
            if request.method == 'GET':
                print("Steve")
                print(request.session.get('product_wishlist'))
                product = Product.objects.get(id=id)
                wishlist  = SessionWishlist(request)
                try:
                    if str(product.id) == request.session.get("product_wishlist")[""+str(product.id)+""]:
                        wishlist.delete(product)
                    return JsonResponse({'status':'true', 'added':'false','message':'Added to wishlist'})
                except:
                    wishlist.add(product)
                    return JsonResponse({'status':'true', 'added':'true','message':'Added to wishlist'})
    else:
        return HttpResponseRedirect("/data/")

	

@login_required(login_url='/login/')
def wishlist_remove(request, id):
    url = request.META.get('HTTP_REFERER')
    obj, created = Wishlist.objects.update_or_create(user=request.user)
    product = get_object_or_404(Product, id=id)
    wishlistItems = WishlistItem.objects.filter(wishlist=obj, product=product)
    wishlistItems.delete()
    return HttpResponseRedirect(url)

 
class MyWishlist(LoginRequiredMixin, ListView):
    model = WishlistItem
    template_name = "mywishlist.html"
    context_object_name = 'saved'
    paginate_by=20
    login_url = '/customer/login/' 


    def get_queryset(self, *args, **kwargs):
        qs = super(MyWishlist, self).get_queryset(*args, **kwargs)
        wishlist, created = Wishlist.objects.get_or_create(user= self.request.user)
        qs = qs.select_related('product').filter(wishlist=wishlist).order_by('-created')
        return qs 