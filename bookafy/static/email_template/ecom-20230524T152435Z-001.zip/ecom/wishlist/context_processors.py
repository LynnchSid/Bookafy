from .models import WishlistItem, Wishlist
from wishlist.wishlist import Wishlist as SessionWishlist
from product.models import Product

def get_wishlist(request):
    if request.user.is_authenticated:
        try:
            wishlist = Wishlist.objects.get(user=request.user)
            wishlist_items = WishlistItem.objects.filter(wishlist=wishlist)
            wishlist_item = []
            for wishlist in wishlist_items:
                wishlist_item.append(wishlist.product)

            return {'wishlists': {'success': True, 'data': wishlist_item }}
        except:
            return {'wishlists': {'success': False, 'data': None }}
    else:
        wishlist = SessionWishlist(request)
        wishlist_id = wishlist.list()

        return {'wishlists': {'success': True, 'data': wishlist_id}}