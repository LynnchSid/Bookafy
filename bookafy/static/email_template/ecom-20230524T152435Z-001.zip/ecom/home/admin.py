from django.contrib import admin
from .models import Pages ,Sliders, Sale, Banner, Adv, Offer

admin.site.register(Pages) 
admin.site.register(Sale)
admin.site.register(Banner)
admin.site.register(Sliders) 
admin.site.register(Adv) 
admin.site.register(Offer) 

