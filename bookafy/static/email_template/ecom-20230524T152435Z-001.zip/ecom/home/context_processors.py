from .models import Pages
from product.models import Category

def pages(request):
    return {'pages': Pages.objects.all().order_by('id')}


def get_category(request):
    categorys = Category.active.all()
    if categorys:
        return {'categorys':{'success': True, 'data': categorys}}
    else:
        return {'categorys':{'success': False, 'data': None}}
