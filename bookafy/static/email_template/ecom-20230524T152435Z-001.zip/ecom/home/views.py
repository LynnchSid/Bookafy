from django.shortcuts import render
from django.views.generic import ListView , DetailView
from product.models import Product, Category
from .models import Pages , Sliders, Sale, Banner, Adv


class Home(ListView):
    template_name = "home.html"
    model = Product

    def get_context_data(self, **kwargs):
        context = super(Home, self).get_context_data(**kwargs)
        context['products'] = Product.active.all()
        context['sales'] = Sale.active.all()
        context['banners'] = Banner.active.all()
        context['advs'] = Adv.active.all()
        context['sliders'] = Sliders.objects.all()
        return context 


class PageDetail(DetailView):
    model = Pages
    template_name = "page.html"

