from django.db import models
from django.urls import reverse
from ckeditor.fields import RichTextField
from product.models import Product
import datetime




class ActiveSaleManager(models.Manager):
    def get_queryset(self):
        return super(ActiveSaleManager, self).get_queryset().filter(is_active=True)
    
class ActiveTopProductManager(models.Manager):
    def get_queryset(self):
        return super(ActiveTopProductManager, self).get_queryset().filter(is_active=True)
    

class ActiveAdvManager(models.Manager):
    def get_queryset(self):
        return super(ActiveAdvManager, self).get_queryset().filter(is_active=True)
    
class ActiveBannerManager(models.Manager):
    def get_queryset(self):
        return super(ActiveBannerManager, self).get_queryset().filter(is_active=True)
    
class ActiveOfferManager(models.Manager):
    def get_queryset(self):
        return super(ActiveOfferManager, self).get_queryset().filter(is_active=True)
    

class Sale(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=False)
    active = ActiveSaleManager()


class Banner(models.Model):
    image = models.ImageField(upload_to="banner")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=False)
    active = ActiveBannerManager()


class Adv(models.Model):
    image = models.ImageField(upload_to='Adv')
    name = models.CharField(max_length=100)
    short_description = models.CharField(max_length=100)
    url = models.CharField(max_length=200)
    is_active = models.BooleanField(default=False)
    active = ActiveAdvManager()


class Sliders(models.Model):
    image = models.ImageField(upload_to='seller/sliders')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=True)

class Offer(models.Model):
    offer_on = models.CharField(max_length=50, null=True)
    offer_time = models.DateField(null=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=False)
    active = ActiveOfferManager()

    def __str__(self):
        return self.offer_on

    class Meta:
        verbose_name = ("Offer")
        verbose_name_plural = ("Offers")
    
    def number_of_days(self):
        today = datetime.datetime.now().date()
        print("messi") 
        return (self.offer_time - today).days + 1  
       
      
 
class Pages(models.Model):
    name = models.CharField(max_length=100)
    content = RichTextField(blank=True)
    slug = models.SlugField(unique=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = ("Page")
        verbose_name_plural = ("Pages")

    def get_absolute_url(self):
        return reverse("pages", kwargs={"slug":self.slug})




