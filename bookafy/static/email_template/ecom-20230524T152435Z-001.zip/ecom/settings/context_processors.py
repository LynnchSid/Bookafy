import datetime
from .models import Settings
from home.models import Offer

def get_company_details(request):
    setting = Settings.load()
    if setting:
        return {'settings': {'success': True, 'data': setting}}
    else:
        return {'settings': {'success': False, 'data': None}}


def get_offer(request):
    offer = Offer.active.filter(offer_time__gte = datetime.datetime.today()).order_by('?').first()
    if offer:
        return {'offers':{'success': True, 'data': offer}}
    else:
        return {'offers':{'success': False, 'data': None}}
