from django.db import models
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.db.models import Count, Sum, Avg
from helper import unique_slug_generator,file_size
from django.db.models.signals import pre_save
from django.template.defaultfilters import slugify
from django.core.exceptions import ValidationError
from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVector, SearchVectorField 
from urllib.parse import urlparse ,parse_qs
from mptt.models import MPTTModel, TreeForeignKey
from ckeditor.fields import RichTextField
from accounts.models import User 
from review.models import Review



class ActiveProductManager(models.Manager):
    def get_queryset(self):
        return super(ActiveProductManager, self).get_queryset().filter(is_active=True)
    


class ActiveCategoryManager(models.Manager):
    def get_queryset(self):
        return super(ActiveCategoryManager, self).get_queryset().filter(is_active=True)



class Category(MPTTModel):
    name = models.CharField(max_length=100)
    parent = TreeForeignKey('self', null=True, blank=True, related_name='children',on_delete=models.SET_NULL)
    icon = models.ImageField(blank=True,upload_to='category/icon',validators=[file_size])
    slug = models.SlugField(unique=True)
    is_active = models.BooleanField(default=False)
    active = ActiveCategoryManager()


    def __str__(self):
        return self.name

    class MPTTMeta:
        order_insertion_by = ['id']

    def get_absolute_url(self):
        return reverse("category", kwargs={"slug":self.slug})

 
class Product(models.Model):
 
    # Basic Information
    title = models.CharField(max_length=500)
    brand = models.CharField(max_length=120, blank= True)

    category = models.ForeignKey('Category',null=True,on_delete=models.SET_NULL,related_name="product_catgeory")
    sub_category = models.ForeignKey('Category',null=True,on_delete=models.SET_NULL,related_name="product_subcatgeory")

    # pricing
    price = models.BigIntegerField()
    without_discount_price = models.BigIntegerField(default=0)
    mrp = models.BigIntegerField()

    #Images
    img = models.ImageField(upload_to='product/' ,validators=[file_size])
    img_second = models.ImageField(blank=True,upload_to='product/',validators=[file_size])
    img_third = models.ImageField(blank=True,upload_to='product/',validators=[file_size])
    img_forth = models.ImageField(blank=True,upload_to='product/',validators=[file_size])
    img_fifth = models.ImageField(blank=True,upload_to='product/',validators=[file_size])
    video = models.URLField(blank=True , null=True)

    #Description
    description = RichTextField(blank=True)

    slug = models.SlugField(null=True, unique=True,max_length=500)
    published = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)  
    is_active = models.BooleanField(default=False)
    objects = models.Manager()
    active = ActiveProductManager()
    search_vector = SearchVectorField(null=True ,blank=True)
    
     
    def __str__(self):
        return self.title

    class Meta:
        verbose_name = ("Product")
        verbose_name_plural = ("Products")
        ordering = ("-published",)

        indexes = [
            GinIndex(fields=['search_vector']),
        ] 

    def get_absolute_url(self):
        return reverse("product_detail", kwargs={"slug":self.slug})

    def status(self):
        if self.is_active:
            return mark_safe('<span class="badge-dot bg-success mr-1 d-inline-block align-middle"></span>Live')
        else:
            return mark_safe('<span class="badge-dot bg-warning mr-1 d-inline-block align-middle"></span>In Review')


    def saved_price(self):
        try:
            return self.without_discount_price-self.mrp
        except:
            pass

 
    def discount_percentage(self):
        if self.saved_price:
            return int((self.saved_price()/self.without_discount_price) * 100)

    def clean(self):
        if self.price > self.mrp:
            raise ValidationError(
                {'price': "Your selling price must be less than maximum retail price."})
        
        if self.mrp > self.without_discount_price:
            raise ValidationError(
                {'without_discount_price': "Your Without Discount price must be greater than MRP Price"})
                   

    # def clean(self):
    #     numProd = Product.objects.filter(seller=self.seller).count()
    #     if numProd > 2:
    #         raise ValidationError("Your user plan does not support more than {} posts".format(numProd))

 
    def average_review(self):
        reviews = Review.objects.select_related("order_item__product" ,'parent').filter(order_item__product=self ,parent__isnull=True).aggregate(average=Avg('stars'))
        avg = 0
        if reviews['average'] is not None:
            avg = float(reviews['average'])
            return avg
        else:
            return avg

    def total_review(self):
        reviews = Review.objects.select_related("order_item__product" ,'parent').filter(
            order_item__product=self,parent__isnull=True).aggregate(count=Count('id'))
        cnt = 0
        if reviews['count'] is not None:
            cnt = (reviews['count'])
            return cnt

    def get_video_id(self):
        u_pars = urlparse(self.video)
        quer_v = parse_qs(u_pars.query).get('v')
        if quer_v:
            return quer_v[0]
        pth = u_pars.path.split('/')
        if pth:
            return pth[-1] 



class VariationManager(models.Manager):
    def get_queryset(self):
        return super(VariationManager, self).get_queryset().all()


class VariationCategoryChoice(models.Model):
    name = models.CharField(max_length=50)

class Variation(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE ,related_name= "product_variation")
    variation_category = models.ForeignKey(VariationCategoryChoice, on_delete=models.CASCADE ,related_name= "product_variation_category")
    variation_value = models.CharField(max_length=100 ,blank=True)

    objects = VariationManager()

    def __str__(self):
        return self.variation_value


 
def product_pre_save_receiver(sender, instance, *args, **kwargs):
    if not instance.slug:
        instance.slug = unique_slug_generator(instance=instance)
    
pre_save.connect(product_pre_save_receiver, sender=Product)  


